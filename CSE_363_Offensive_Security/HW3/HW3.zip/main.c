//
// Created by xgao on 4/6/20.
//

#include <stdlib.h>
#include <string.h>
#include <stdio.h>

typedef unsigned char byte;
#define true 1

void* get_key(char *random_string){
    void *retVal;
    size_t random_string_len;
    uint count;

    retVal = calloc(0x100,1);
    random_string_len = strlen(random_string);
    count = 0;
    while (count < random_string_len) {
        *(byte *)(count + (int)retVal) = random_string[count] ^ 0x1c;
        count = count + 1;
    }
    return retVal;
}

void print_wrong_number(void){
    puts("Wrong number");
    exit(1);
}

int get_number(void){
    size_t another_buffer_len;
    int integer_of_count_char;
    char char_at_count;
    char char_at_count_plus;
    char char_at_count_plus_two;
    int useless_var;
    char user_input_buffer [64];
    char another_buffer [10];
    int scanf_retVal;
    int another_buffer_index;
    uint user_input_buffer_index;

    printf("Enter the right number: ");
    scanf_retVal = scanf("%27s",user_input_buffer);
    if (scanf_retVal != 1) {
        print_wrong_number();
    }
    if (user_input_buffer[0] != '0') {
        print_wrong_number();
    }
    if (user_input_buffer[1] != '6') {
        print_wrong_number();
    }
    fflush(stdin);
    memset(another_buffer,0,10);
    useless_var = 0;
    user_input_buffer_index = 0;
    another_buffer_index = 0;
    while( true ) {
        another_buffer_len = strlen(another_buffer);
        if (8 < another_buffer_len) break;
        another_buffer_len = strlen(user_input_buffer);
        if (another_buffer_len <= user_input_buffer_index) break;
        char_at_count = user_input_buffer[user_input_buffer_index];
        char_at_count_plus = user_input_buffer[user_input_buffer_index + 1];
        char_at_count_plus_two = user_input_buffer[user_input_buffer_index + 2];
        integer_of_count_char = atoi(&char_at_count);
        another_buffer[another_buffer_index] = (char)integer_of_count_char;
        another_buffer[another_buffer_index] = another_buffer[another_buffer_index] + '\x03';
        user_input_buffer_index = user_input_buffer_index + 3;
        another_buffer_index = another_buffer_index + 1;
    }
    another_buffer[another_buffer_index] = '\0';
    printf("%s\n", another_buffer);
    integer_of_count_char = strcmp(another_buffer,"CSE363ESC");
    if (integer_of_count_char == 0) {
        printf("Your number corresponds to %s, well done!\n",another_buffer);
    }
    else {
        print_wrong_number();
    }
    return 0;
}


int main(int argc,char **argv){
    void* key = key = get_key("\x7foy/*/szzoy\x7f.,.,");
    printf("passwd for key is %s\n", key);

    get_number();
}