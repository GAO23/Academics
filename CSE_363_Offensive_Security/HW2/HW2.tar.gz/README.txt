Not really sure why but dns spoofing doesn't seem to work properly. 
Anyways I am submitting what I have so far hoping for partial credits.

